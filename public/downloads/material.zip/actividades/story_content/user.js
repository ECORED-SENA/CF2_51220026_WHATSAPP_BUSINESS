function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Is4Vo2Sxle":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

